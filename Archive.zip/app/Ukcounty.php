<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ukcounty extends Model
{
   protected $table = 'ukcounties';
}
