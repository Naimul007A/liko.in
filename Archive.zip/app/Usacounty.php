<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Usacounty extends Model
{
   protected $table = 'usacounties';
}
