<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Usaschool extends Model
{
   protected $table = 'usaschools';
}
