<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Usastate extends Model
{
   protected $table = 'usastates';
}
