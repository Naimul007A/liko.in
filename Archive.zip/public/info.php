<?php
phpinfo()  
?>