<footer>
<p>
<a class="nav-link" rel="nofollow" href="/privacy">Privacy Policy</a> | <a class="nav-link" rel="nofollow" href="/terms-of-use">Terms of Use</a> | <a class="nav-link" rel="nofollow" href="/contact-us">Contact Us</a> | © 2017 Copyright Liko.In | {{ (microtime(true) - LARAVEL_START) }}
</p>	
</footer>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-201417217-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-201417217-1');
</script>

<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script data-ad-client="ca-pub-7984072286121296" async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
</body> 
</html>