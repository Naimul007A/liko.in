﻿<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="MobileOptimized" content="width" />		
	<meta name="HandheldFriendly" content="true" />
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<link rel="shortcut icon" href="/favicon.ico" />
	@yield('meta')
	<link rel="stylesheet" href="https://liko.in/css/liko1.css">
	<!--meta data Ads -->
<meta name="google-adsense-account" content="ca-pub-4665700596576325">
<!--Adsense Sniped Code -->
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4665700596576325"
     crossorigin="anonymous"></script>
</head>
<body>
<header>
   
	<div id="logo"><a href="https://liko.in/" alt="Liko.In"><img src="https://liko.in/logo.png"></a></div>
</header>
