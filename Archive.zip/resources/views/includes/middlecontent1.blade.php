<!-- Ezoic - middle_content - mid_content -->
<div id="ezoic-pub-ad-placeholder-107"></div>
<!-- End Ezoic - middle_content - mid_content -->