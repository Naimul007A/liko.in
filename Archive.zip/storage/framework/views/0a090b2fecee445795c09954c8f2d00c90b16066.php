<?php $__env->startSection('meta'); ?>
<title><?php echo e($page->name); ?> state- District wise schools list | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
		<h1><?php echo e($page->name); ?> state Schools</h1>
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
		<p>Select a district in the state of <?php echo e($page->name); ?> to view all the schools.</p>
<?php echo $__env->make('includes.centerad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
		<ul class="double li"> 
		<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
			<li><a href="/districts/<?php echo e($item->slug); ?>">Schools in <?php echo e($item->name); ?></a></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
		</ul>
		<p>Select a City in the state of <?php echo e($page->name); ?> to view all the schools.</p>
<?php echo $__env->make('includes.middlecontent1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
		<p> 
		<?php $__empty_1 = true; $__currentLoopData = $item1s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
			<a href="/cities/<?php echo e($item1->slug); ?>"><?php echo e($item1->name); ?></a>&nbsp;&nbsp;| &nbsp;&nbsp;
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
		</p>
<?php $__env->stopSection(); ?>				
<?php $__env->startSection('breadcrumb'); ?>	
  		<ul class="breadcrumb">
		  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
		  <li><a href="/states">India</a></li>
		  <li><?php echo e($page->name); ?></li>
		</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>