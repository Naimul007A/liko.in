<?php $__env->startSection('meta'); ?>
<title>Schools in India Block-wise, select a Block to find schools list | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
	<h1>Schools in India Block-wise </h1>
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
		<p>Schools list of all Blocks in India- select a Block to find schools list</p>
			<div style="overflow-x:auto;">          
				<table>
				<thead>
				<tr>
				<th>Block name</th>
				<th>District</th>
				<th>State</th>
				</tr>
				</thead>
				<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>				
					<tr>
					<td><a href="/blocks/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></td>
					<td><a href="/districts/<?php echo e($item->district_url); ?>"><?php echo e($item->district_name); ?></a></td>
					<td><?php echo e($item->state_name); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> <?php endif; ?>							
				</tbody>
				</table>
			</div>
	
<?php echo e($items->links()); ?>

<?php $__env->stopSection(); ?>				
<?php $__env->startSection('breadcrumb'); ?>
		<ul class="breadcrumb">
		  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
		  <li>Blocks</li>
		</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>