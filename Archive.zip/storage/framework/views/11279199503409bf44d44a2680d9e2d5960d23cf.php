<?php $__env->startSection('meta'); ?>
<title><?php echo e($page->name); ?>, <?php echo e($page->address); ?> | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1><?php echo e($page->name); ?></h1>
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<p><?php echo e($page->name); ?>, is located at <?php echo e($page->address); ?></p>
	<p>Name of the School: <b><?php echo e($page->name); ?></b><br>
		Administered by: <?php echo e($page->runby); ?><br>
		Post Box: <?php echo e($page->po); ?><br>
		Phone Number: <b><?php echo e($page->phone); ?></b><br>
	</p>
<?php echo $__env->make('includes.centerad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<h3>Location</h3>
	<p>Address: <b><?php echo e($page->address); ?></b><br>
		Postal Zip Code: <?php echo e($page->postal); ?><br>
		County : <?php echo e($page->county); ?><br>
		State: <?php echo e($page->state); ?><br>
		Contact Number: <?php echo e($page->phone); ?></p>
<?php echo $__env->make('includes.middlecontent1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>			
	<p><?php echo e($page->name); ?> is located in <?php echo e($page->county); ?>, in United Staes of America (U.S.A) and run by <b><?php echo e($page->runby); ?></b></p>
<?php echo $__env->make('includes.middlecontent1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
	<p>Please Note: Updated on 05/08/2016. Contact School or visit <?php echo e($page->name); ?> website for updated information.</p>
	<h3>More Schools</h3>
	<ul class="double li"> 
		<?php $__empty_1 = true; $__currentLoopData = $relateds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
		<li><a href="/usa-schools/<?php echo e($related->slug); ?>"><?php echo e($related->name); ?>, <?php echo e($related->postal); ?></a></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
	</ul>
<?php echo $__env->make('includes.longcontent1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<h3>More Counties</h3>
	<p> 
		<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
		<a href="/usa-counties/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a>&nbsp;&nbsp;| &nbsp;&nbsp;
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
	</p>
<?php $__env->stopSection(); ?>				
<?php $__env->startSection('breadcrumb'); ?>	
		<ul class="breadcrumb">
		  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
		  <li><a href="/usa-states">School in U.S.A</a></li>
		  <li><a href="/usa-states/<?php echo e($b2->state_url); ?>"><?php echo e($b2->state); ?></a></li>
		  <li><a href="/usa-counties/<?php echo e($b2->slug); ?>"><?php echo e($b2->name); ?></a></li>
		  <li><?php echo e($page->name); ?></li>
		</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>