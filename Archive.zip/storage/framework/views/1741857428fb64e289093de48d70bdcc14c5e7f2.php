<?php $__env->startSection('meta'); ?>
<meta name="robots" content="noindex">
<title>Contact Us</title>
<?php $__env->stopSection(); ?>	

<?php $__env->startSection('content'); ?>   
<section id="pageContent">
	<main role="main">
		<article>	   
			<h1>Contact Us</h1>		    
			<p>Please contact us for any issues with our website content by E-mail</p>
			<p>We will address any questions, comments and concerns about our online privacy practice and policy.<br>
				Please include the following without fail:<br>
				<ul>
					<li>1. The page URL of our website that has to be modified or deleted.</li>
				<li>2. The reason of your request.</li>
				<li>3.Your contact Email id and or address and phone numbers for confirming.</li>
				</ul></p>
				 <p>Please write to us at Email: <a href="mailto:panchamithracreators@gmail.com">panchamithracreators@gmail.com</a>.<br>
			Date Updated: 18 July 2017.</p> 
		</article>
	</main>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>