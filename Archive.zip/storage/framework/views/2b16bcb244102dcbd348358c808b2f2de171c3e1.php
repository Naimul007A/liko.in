<?php $__env->startSection('meta'); ?>
<title>Search Results for "<?php echo e($q); ?>" | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
     <h1>Search Results for "<?php echo e($q); ?>"</h1>
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>	 
		<ul class="listings">
		<?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
		 <li><a href="/<?php echo e($post->url); ?><?php echo e($post->slug); ?>"><?php echo e($post->name); ?></a></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<h3>No Results</h3>
		<?php endif; ?>
		</ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>