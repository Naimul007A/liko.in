<?php $__env->startSection('meta'); ?>
<title>Schools in <?php echo e($page->name); ?> County | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
	<h1>Schools in <?php echo e($page->name); ?> County</h1>
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<p>List of all schools in <?php echo e($page->name); ?> county, U.S.A. Click the school link to view all details of the schools.</p>
<?php echo $__env->make('includes.centerad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
		<div style="overflow-x:auto;">          
				<table>
				<thead>
				<tr>
				<th>School name</th>
				<th>Address</th>
				<th>Phone</th>
				</tr>
				</thead>
				<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>				
					<tr>
					<td><a href="/usa-schools/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></td>
					<td><?php echo e($item->address); ?></td>
					<td><?php echo e($item->phone); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> <?php endif; ?>							
				</tbody>
				</table>
			</div>			
  <?php echo e($items->links()); ?>	
  <?php $__env->stopSection(); ?>				
<?php $__env->startSection('breadcrumb'); ?>
		<ul class="breadcrumb">
		  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
		  <li><a href="/usa-states">School in U.S.A</a></li>
		  <li><a href="/usa-states/<?php echo e($page->state_url); ?>"><?php echo e($page->state); ?></a></li>
		  <li><?php echo e($page->name); ?></li>
		</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>