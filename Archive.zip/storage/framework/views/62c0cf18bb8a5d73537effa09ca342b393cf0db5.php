<?php $__env->startSection('meta'); ?>
<title><?php echo e($page->name); ?> city schools list | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
 
	<h1>School list <?php echo e($page->name); ?> city</h1>
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
		<p>Select a Pin Code in <?php echo e($page->name); ?> city in the state of <?php echo e($page->state); ?> to view all the schools list</p>
<?php echo $__env->make('includes.centerad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
		<p> 
		<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
			<a href="/pincodes/<?php echo e($item->slug); ?>"><?php echo e($item->pin_code); ?></a>&nbsp;&nbsp;| &nbsp;&nbsp;
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
		</p>
<?php $__env->stopSection(); ?>				
<?php $__env->startSection('breadcrumb'); ?>	
		<ul class="breadcrumb">
		  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
		  <li><a href="/states">India</a></li>
		  <li><a href="/states/<?php echo e($page->state_url); ?>"><?php echo e($page->state); ?></a></li>
		  <li><?php echo e($page->name); ?></li>
		</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>