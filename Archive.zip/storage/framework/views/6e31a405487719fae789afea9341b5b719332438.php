<!-- Ezoic - Middle Content1 - mid_content -->
<div id="ezoic-pub-ad-placeholder-104">
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- liko-center-ad -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-7984072286121296"
     data-ad-slot="1079234378"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
<!-- End Ezoic - Middle Content1 - mid_content -->