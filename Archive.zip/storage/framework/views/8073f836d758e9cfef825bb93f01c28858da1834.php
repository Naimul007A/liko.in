<?php $__env->startSection('meta'); ?>
<title>List of Schools <?php echo e($page->name); ?> County in U.K | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
		<h1>List of Schools <?php echo e($page->name); ?> County in U.K</h1>
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div style="overflow-x:auto;">          
				<table>
				<thead>
				<tr>
				<th>School name</th>
				<th>Address</th>
				<th>Phone</th>
				</tr>
				</thead>
				<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>				
					<tr>
					<td><a href="/uk-schools/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></td>
					<td><?php echo e($item->address); ?></td>
					<td><?php echo e($item->phone); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> <?php endif; ?>							
				</tbody>
				</table>
			</div>	
  <?php echo e($items->links()); ?>	
<?php $__env->stopSection(); ?>				
<?php $__env->startSection('breadcrumb'); ?>
		<ul class="breadcrumb">
		  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
		  <li><a href="/uk-counties">U.K Schools</a></li>
		  <li><?php echo e($page->name); ?></li>
		</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>