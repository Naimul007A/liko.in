﻿<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="MobileOptimized" content="width" />		
	<meta name="HandheldFriendly" content="true" />
	<meta name="apple-mobile-web-app-capable" content="yes" />
	<link rel="shortcut icon" href="/favicon.ico" />
	<?php echo $__env->yieldContent('meta'); ?>
	<link rel="stylesheet" href="/css/liko1.css">
</head>
<body>
<header>
	<div id="logo"><a href="/" alt="Liko.In"><img src="/logo.png"></a></div>
</header>
