<?php $__env->startSection('meta'); ?>
<meta name="robots" content="noindex">
<title>404 Error - Page not found</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
<section id="pageContent">
	<main role="main">
		<article>	   
			<h1>404</h1>
			<p>Page not found!!</p>
    				<p>We are extemely sorry about this.<br>
						The reason could be that we could have deleted or changed the page you have tried.<br>
						You May try to search and find your queries from  here</p>
			
					<b>Please browse through -</b>

		</article>
	</main>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>