<?php $__env->startSection('meta'); ?>
<title>Schools list in India; Find a School in India | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1>Schools list in India; Find a School in India</h1>
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
		<p>More than 1400000 schools are there all over India. Enter the school name in the search box above or browse through the state list.<br>Indian Schools listed Statewise</p>
<?php echo $__env->make('includes.centerad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
		<ul class="double li"> 
		<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
			<li><a href="/states/<?php echo e($item->slug); ?>">Schools in <?php echo e($item->name); ?></a></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
		</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>