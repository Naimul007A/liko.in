<footer>
<p>
<a class="nav-link" rel="nofollow" href="/privacy">Privacy Policy</a> | <a class="nav-link" rel="nofollow" href="/terms-of-use">Terms of Use</a> | <a class="nav-link" rel="nofollow" href="/contact-us">Contact Us</a> | © 2017 Copyright Liko.In | <?php echo e((microtime(true) - LARAVEL_START)); ?>

</p>	
</footer>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-46057781-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-46057781-1');
</script>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({
          google_ad_client: "ca-pub-3744039630714755",
          enable_page_level_ads: true
     });
</script>
</body> 
</html>