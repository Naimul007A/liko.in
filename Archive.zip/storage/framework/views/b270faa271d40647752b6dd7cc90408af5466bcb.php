<?php $__env->startSection('meta'); ?>
<title><?php echo e($page->name); ?> school, <?php echo e($page->village); ?>, <?php echo e($page->block); ?> taluk school | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 


  
	<h1><?php echo e($page->name); ?>- <?php echo e($page->village); ?> School</h1>
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<p><?php echo e($page->name); ?>, is situated in the village of <?php echo e($page->village); ?>, <?php echo e($page->block); ?> Block, <?php echo e($page->district); ?> District, <?php echo e($page->state); ?> State, India.<br></p>	
	<p><?php echo e($page->name); ?>, <?php echo e($page->village); ?> school information is as below:.<br></p>
<?php echo $__env->make('includes.centerad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
		<p>
		School name: <?php echo e($page->name); ?>, <?php echo e($page->block); ?><br>
		Village : <?php echo e($page->village); ?><br>
		Block : <?php echo e($page->block); ?><br>
		</p>
		<p>	
		Cluster : <?php echo e($page->cluster); ?><br>
		District : <?php echo e($page->district); ?><br>
		State : <?php echo e($page->state); ?><br>
		Pincode Number : <?php echo e($page->pincode); ?><br></p>
<?php echo $__env->make('includes.middlecontent1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>			
	<h2>Management of <?php echo e($page->name); ?></h2>
		
		<p>School Code : <?php echo e($page->school_code); ?><br>
		Head Master : <?php echo e($page->name_of_the_head_master); ?><br>
		Management : <?php echo e($page->management); ?><br></p>
	
	<h3>Admissions in <?php echo e($page->name); ?></h3>
			
		<p>Category : <?php echo e($page->school_category); ?><br>
		Type : <?php echo e($page->type_of_school); ?><br>
		Lowest Class : <?php echo e($page->lowest_class_in_school); ?><br>
		Highest Class : <?php echo e($page->highest_class_in_school); ?><br>
		Medium Of Instruction : <?php echo e($page->medium_of_instructions); ?><br>
		<b>Note:</b> All the above <?php echo e($page->name); ?> information were collected in the year 2011 and you may please approach the <?php echo e($page->name); ?> for current status.<br>
		</p>
<?php echo $__env->make('includes.longcontent1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
	<h3>More Schools</h3>	
		<ul class="listings"> 
		<?php $__empty_1 = true; $__currentLoopData = $relateds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
			<li><a href="/schools-in-india/<?php echo e($related->slug); ?>"><?php echo e($related->name); ?>, <?php echo e($related->village); ?></a></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
		</ul>
	<h3>More Blocks</h3>	
		<p> 
		<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
			<a href="/blocks/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a>&nbsp;&nbsp;| &nbsp;&nbsp;
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
		</p>
<?php $__env->stopSection(); ?>				
<?php $__env->startSection('breadcrumb'); ?>	
		<ul class="breadcrumb">
		  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
		  <li><a href="/states">India</a></li>
		  <li><a href="/states/<?php echo e($blockid->state_url); ?>"><?php echo e($blockid->state_name); ?></a></li>
		  <li><a href="/districts/<?php echo e($blockid->district_url); ?>"><?php echo e($blockid->district_name); ?></a></li>
		  <li><a href="/blocks/<?php echo e($blockid->slug); ?>"><?php echo e($blockid->name); ?></a></li>
		  <li><?php echo e($page->name); ?></li>
		</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>