<?php $__env->startSection('meta'); ?>
<title><?php echo e($page->name); ?> block, <?php echo e($page->district_name); ?> Schools List | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1><?php echo e($page->name); ?> block, <?php echo e($page->district_name); ?> Schools List</h1>
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<p>Schools list located in <?php echo e($page->name); ?>, in the <?php echo e($page->district); ?> district in the state of <?php echo e($page->state); ?></p>
<?php echo $__env->make('includes.centerad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<div style="overflow-x:auto;">          
				<table>
				<thead>
				<tr>
				<th>School name</th>
				<th>Village</th>
				<th>Cluster</th>
				<th>Pin Code</th>
				</tr>
				</thead>
				<tbody>
				<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>				
					<tr>
					<td><a href="/schools-in-india/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a></td>
					<td><?php echo e($item->village); ?></td>
					<td><?php echo e($item->cluster); ?></td>
					<td><?php echo e($item->pincode); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> <?php endif; ?>							
				</tbody>
				</table>
			</div>	
<?php echo e($items->links()); ?>

<?php $__env->stopSection(); ?>				
<?php $__env->startSection('breadcrumb'); ?>
		<ul class="breadcrumb">
		  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
		  <li><a href="/states">India</a></li>
		  <li><a href="/states/<?php echo e($page->state_url); ?>"><?php echo e($page->state_name); ?></a></li>
		  <li><a href="/districts/<?php echo e($page->district_url); ?>"><?php echo e($page->district_name); ?></a></li>
		  <li><?php echo e($page->name); ?></li>
		</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>