<?php $__env->startSection('meta'); ?>
<title>Find a School in U.S.A (United States of America), County wise schools list | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
	<h1>Find a School in U.S.A (United States of America)</h1>
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		
	<h2>View Counties by State</h2>
		<p> 
		<?php $__empty_1 = true; $__currentLoopData = $item1s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
			<a href="/usa-states/<?php echo e($item1->slug); ?>"><?php echo e($item1->name); ?></a>&nbsp;&nbsp;| &nbsp;&nbsp;
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
		</p>
<?php echo $__env->make('includes.centerad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>	
	<h3>Counties List. Select a County</h3>
		<ol> 
		<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
			<li><a href="/usa-counties/<?php echo e($item->slug); ?>">Schools in <?php echo e($item->name); ?>, <?php echo e($item->state); ?></a></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
		</ol>	
	<?php echo e($items->links()); ?>

<?php $__env->stopSection(); ?>				
<?php $__env->startSection('breadcrumb'); ?>	
	<ul class="breadcrumb">
		  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
		  <li><a href="/usa-states">School in U.S.A</a></li>
		  <li>Counties in U.S.A</li>
		</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>