<?php $__env->startSection('meta'); ?>
<title><?php echo e($page->name); ?>, <?php echo e($page->address); ?> | Liko.In - Schools near you</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
	<h1><?php echo e($page->name); ?></h1>
		<p><?php echo e($page->name); ?>, is located at <?php echo e($page->address); ?></p>	
<?php echo $__env->make('includes.topad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<p>Name of the School: <b><?php echo e($page->name); ?></b><br>
			Type: <?php echo e($page->type); ?><br>
			Status: <?php echo e($page->status); ?><br>
			Head: <?php echo e($page->head); ?><br>
			Phone Number: <b><?php echo e($page->phone); ?></b><br>
		</p>		
<?php echo $__env->make('includes.centerad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<p>Address: <b><?php echo e($page->address); ?></b><br>
		Zip Code: <b><?php echo e($page->postal); ?></b><br>
		Contact Number: <?php echo e($page->phone); ?></p>	
	
	<p><?php echo e($page->type); ?> named as <?php echo e($page->name); ?> is located in <?php echo e($page->county); ?>, in United Kingdom and current status is <?php echo e($page->status); ?>.<br></p>	
 <?php echo $__env->make('includes.middlecontent1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 	
	<h3>Location</h3>
	<p>Address: <?php echo e($page->address); ?><br>
		Postal Zip Code: <?php echo e($page->postal); ?><br>
		County : <b><?php echo e($page->county); ?></b><br>
		GOR: <?php echo e($page->gor); ?><br>
		Ward: <b><?php echo e($page->ward); ?></b><br>
		Consituency: <?php echo e($page->constituency); ?></p>
<?php echo $__env->make('includes.longcontent1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>		
	<h3><?php echo e($page->name); ?> School Information</h3>
			
	<p>Phase: <?php echo e($page->phase); ?><br>
		Boarders: <?php echo e($page->boarders); ?><br>
		Gender: <?php echo e($page->gender); ?><br>
		Religious: <?php echo e($page->religion); ?><br>
		</p>
	<p>Please Note: Updated on 05/08/2016. Contact School or visit <?php echo e($page->name); ?> website for updated information.</p>
	<h3>More Schools</h3>
		<ul class="listings"> 
		<?php $__empty_1 = true; $__currentLoopData = $relateds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
			<li><a href="/uk-schools/<?php echo e($related->slug); ?>"><?php echo e($related->name); ?>, <?php echo e($related->postal); ?></a></li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
		</ul>
	<h3>More Counties</h3>
		<p> 
		<?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>	
			<a href="/uk-counties/<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></a><?php echo $__env->make('includes.centerad', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>	<h3>No Results</h3> 
		<?php endif; ?> 
		</p>
<?php $__env->stopSection(); ?>				
<?php $__env->startSection('breadcrumb'); ?>	
		<ul class="breadcrumb">
		  <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
		  <li><a href="/uk-counties">U.K Schools</a></li>
		  <li><a href="/uk-counties/<?php echo e($page->county_url); ?>"><?php echo e($page->county); ?></a></li>
		  <li><?php echo e($page->name); ?></li>
		</ul>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>